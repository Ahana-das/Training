package ThreadEx;

class Test85 implements Runnable{

	@Override
	public void run() {
		Thread.currentThread().setName("hello");
		for(int i=0;i<10;i++)
		{
			System.out.println(Thread.currentThread());
			System.out.println("child thread");
		}
	}
	
}
public class ThreadPrioEx {
	public static void main(String[] args) {
		Thread.currentThread().setPriority(10);
		Test test=new Test();
		Thread t=new Thread(test);
		t.start();
		Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
		Thread.currentThread().setName("ahana");
		
		for(int i=0;i<10;i++)
		{
			System.out.println(Thread.currentThread());
			System.out.println("parent thread");
		}

	}

}
