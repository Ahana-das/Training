package ThreadEx;

class First {
	public synchronized void display(String msg) 
	{
		System.out.println("[" + msg);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("]");
	}
}

class Second extends Thread{
	String msg;
	First fobj; //has - a
	
	Second(First fobj,String msg){
		this.fobj=fobj;
		this.msg=msg;
		this.start();
	}
	public void run(){
		fobj.display(msg);
	}
}
public class ThreadWithSync {
	public static void main(String[] args) {
		First fnew=new First();
		Second ss=new Second(fnew, "welcome");
		Second ss1=new Second(fnew, "new");
		Second ss2=new Second(fnew , "java programmer");
	}

}
