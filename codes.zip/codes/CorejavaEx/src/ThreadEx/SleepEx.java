package ThreadEx;

class Test25 extends Thread {

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("child thread");
		}
	}

}

public class SleepEx {
	public static void main(String[] args) {
		Test25 test = new Test25();
		
		test.start();

		for (int i = 0; i < 10; i++) {
			System.out.println("parent thread");
		}

	}

}
