package ThreadEx;

class Test26 extends Thread {

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("child thread");
		}
	}

}

public class JoinEx {
	public static void main(String[] args) throws InterruptedException {
		Test26 test = new Test26();
		
		test.start();
		test.join();

		for (int i = 0; i < 10; i++) {
			System.out.println("parent thread");
		}

	}

}

