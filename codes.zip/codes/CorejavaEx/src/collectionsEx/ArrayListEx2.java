package collectionsEx;

	import java.util.ArrayList;
	import java.util.LinkedList;

	 class Emp1 {
		int id;
		int Salary;
		String name;
		
		Emp1(int idno , int sal , String ename){
			id=idno;
			Salary=sal;
			name=ename;
		}

		@Override
		public String toString() {
			return "Emp1 [eid=" + id + ", eSalary=" + Salary + ", ename=" + name + "]\n";
		}
	 }
		public class ArrayListEx2 {
			public static void main(String[] args) {
				Emp1 e=new Emp1(1,15000,"ahana");
				Emp1 e1=new Emp1(2,16000,"sahana");
				ArrayList al=new ArrayList();
				al.add(e);
				al.add(e1);
				System.out.println(al);
				
			}
		}

		
	
