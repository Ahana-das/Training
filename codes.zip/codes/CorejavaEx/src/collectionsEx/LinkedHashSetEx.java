package collectionsEx;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class LinkedHashSetEx {
	public static void main(String[] args) {
		LinkedHashSet hs=new LinkedHashSet();
		hs.add(12);
		hs.add("abc");
		hs.add(12);
		hs.add(true);
		System.out.println(hs);
	}

}



