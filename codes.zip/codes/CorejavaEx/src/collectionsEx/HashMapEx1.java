package collectionsEx;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapEx1 {
	public static void main(String[] args) {
		HashMap<Integer, String> hm = new HashMap<Integer,String>();
		HashMap hm1=new HashMap();
		
		hm.put(123,"ahana");
		hm.put(124,"sahana");
		hm.put(126,"areena");
		hm1.put("ab","diya");
		System.out.println(hm);
		System.out.println(hm1);
		System.out.println(hm.get(126));
		hm.replace(123, "agu");
		System.out.println(hm.isEmpty());
		System.out.println(hm);
		Set set=hm.entrySet();
		Iterator itr=set.iterator();
		while(itr.hasNext())
		{	
			Entry entry=(Entry) itr.next();
			System.out.println(entry.getKey()+" ");
			System.out.println(entry.getValue()+" ");

			
		}
			




		
	}

}
