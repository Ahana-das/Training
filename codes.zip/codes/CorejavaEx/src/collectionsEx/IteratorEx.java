package collectionsEx;

import java.util.ArrayList;
import java.util.Iterator;

public class IteratorEx {
	public static void main(String[] args) {
		ArrayList al=new ArrayList(); //default size is 10
		al.add("ahana");
		al.add("diya");
		al.add("xtz");
		al.add("xtz");
		System.out.println(al);
		Iterator itr = al.iterator();
		while(itr.hasNext())
		{	
			String name=(String) itr.next();
			if(name.equals("xtz"))
			{
				itr.remove();
			}
			else
			System.out.println(name);
		}
	}

}
