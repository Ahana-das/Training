package collectionsEx;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;

class Emp13 {
	int id;
	int Salary;
	String name;
	
	Emp13(int idno , int sal , String ename){
		id=idno;
		Salary=sal;
		name=ename;
	}

	@Override
	public String toString() {
		return "Emp1 [eid=" + id + ", eSalary=" + Salary + ", ename=" + name + "]\n";
	}
}

public class MapEx {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		Emp13 e=new Emp13(1,15000,"ahana");
		Emp13 e1=new Emp13(2,16000,"sahana");
		Emp13 e2=new Emp13(3,25000,"areehana");
		HashMap<String, Object> hm = new HashMap<String,Object>();
		HashMap hm1=new HashMap();
		
		hm.put("8697459468", e);
		hm.put("8697459552", e1);
		hm.put("9697459552", e2);
		System.out.println("Enter the mobile number:");
		String s=sc.next();
		//System.out.println(hm.get(s)); //everything will be printed
		Emp13 emp= (Emp13) hm.get(s); //only salary will be printed
		System.out.println("your salary:" + emp.Salary);
		System.out.println("your updated salary:" + (emp.Salary+1000));
		
		//System.out.println(hm.get("8697459468"));
		//System.out.println(hm.get("9697459552"));
		Set set=hm.entrySet();
		Iterator itr=set.iterator();
		while(itr.hasNext())
		{	
			Entry entry=(Entry) itr.next();
			//System.out.println(entry.getKey()+" ");
			//System.out.println(entry.getValue()+" ");

			
		}
			

		
		
	}

}
