package collectionsEx;

public class Employee1 {

}
