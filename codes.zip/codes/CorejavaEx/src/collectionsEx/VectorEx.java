package collectionsEx;

import java.util.Vector;

public class VectorEx {
	public static void main(String[] args) {
		Vector v1=new Vector();
		v1.addElement("ahana");
		v1.addElement("sourav");
		v1.addElement("hello");
		v1.addElement("hi");
		System.out.println(v1);
		v1.remove("hello");
		System.out.println(v1);
		v1.remove(3);
		System.out.println(v1);
		System.out.println(v1.elementAt(1));
		System.out.println(v1.lastElement());
		System.out.println(v1.size());
		System.out.println(v1.capacity());
		
	}

}