package collectionsEx;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListIteratorEx {
	public static void main(String[] args) {
			ArrayList al=new ArrayList(); //default size is 10
			al.add("ahana");
			al.add("diya");
			al.add("xtz");
			al.add("xtz");
			System.out.println(al);
			
			ListIterator litr= al.listIterator();
			while(litr.hasNext())
			{	
				
					System.out.println(litr.next());
				
			}
			System.out.println("*******************************");
			while(litr.hasPrevious())
			{
				String val=(String)litr.previous();
				if(val.equals("ahana")){
					litr.add("hello");
					System.out.println(litr.next());
					litr.previous();
				}else{
					System.out.println(val);
				}
			}
	}

}
