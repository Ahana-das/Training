package collectionsEx;

public class CompareToEx {
	public static void main(String[] args) {
		System.out.println("A".compareTo("Z"));
		System.out.println("Z".compareTo("K"));
		System.out.println("A".compareTo("A"));
		
		//return -ve when object1 has to come before object2
		//return +ve when object1 has to come after object2
		//return 0 when object1 & object2 are equal
	}

}
