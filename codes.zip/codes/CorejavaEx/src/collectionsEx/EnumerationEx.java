package collectionsEx;

import java.util.Enumeration;
import java.util.Vector;

public class EnumerationEx {
	public static void main(String[] args) {
		Vector v1=new Vector();
		v1.addElement("ahana");
		v1.addElement("sourav");
		v1.addElement("hello");
		v1.addElement("hi");
		System.out.println(v1);
		Enumeration en=v1.elements();
		while(en.hasMoreElements())
		{
			
			System.out.println(en.nextElement());
		}

}
}
