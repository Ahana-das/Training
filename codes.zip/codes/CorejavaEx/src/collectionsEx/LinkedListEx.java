package collectionsEx;

import java.util.LinkedList;

public class LinkedListEx {
	public static void main(String[] args) {
		LinkedList al=new LinkedList();
		al.add(1);
		al.add(4);
		al.add("xtz");
		al.add("xtz");
		System.out.println(al);
		
		LinkedList al1=new LinkedList();

		al1.add(15);
		al1.add(52);
		al1.add("abc");
		al1.add("abc");
		al1.addAll(al);
		System.out.println(al1);
		al1.remove(2);
		al1.retainAll(al1);
		System.out.println(al1);
		//al1.removeAll(al);
		//System.out.println(al1);
		//al1.clear();
		System.out.println(al1);
		System.out.println(al.isEmpty());
		System.out.println(al1.contains("abc"));
		System.out.println(al1.containsAll(al1));
		System.out.println(al1.equals(al));
		System.out.println(al1.size());
		al1.addFirst("ahana");
		System.out.println(al1);
		
		
	}

}
