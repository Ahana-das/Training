package collectionsEx;

import java.util.HashSet;

public class HashSetEx {
	public static void main(String[] args) {
		HashSet hs=new HashSet();
		hs.add(12);
		hs.add("abc");
		hs.add(12);
		hs.add(true);
		System.out.println(hs);
	}

}
