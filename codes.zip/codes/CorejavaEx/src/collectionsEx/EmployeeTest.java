package collectionsEx;


import java.util.Comparator;
import java.util.TreeSet;


class Employee12 implements Comparable
{
    String name;
    int eid;
    public Employee12(String name, int eid) {
        super();
        this.name = name;
        this.eid = eid;
    }
    @Override
    public int compareTo(Object obj1) {
        // TODO Auto-generated method stub
        int eid1=this.eid;
        Employee12 a=(Employee12) obj1;
        int eid2=a.eid;
        if(eid1>eid2)
            return +1;
        else if(eid2>eid1)
            return -1;
            else
                return 0;
    }
    @Override
    public String toString() {
        return name +"-- "+ eid;
    }
}


class MyComparator5 implements Comparator
{
    public int compare(Object obj1,Object obj2)
    {
        Employee12 e1=(Employee12) obj1;
        Employee12 e2=(Employee12) obj2;
        String s1=e1.name;
        String s2=e2.name;
        return -s1.compareTo(s2);
    }
}


public class EmployeeTest {
    public static void main(String[] args) {
        
        Employee12 e=new Employee12("suresh", 100);
        Employee12 e1=new Employee12("shubham", 200);
        Employee12 e2=new Employee12("ramesh", 250);
        Employee12 e3=new Employee12("ram", 220);
        Employee12 e4=new Employee12("shyam", 10);
        Employee12 e5=new Employee12("ganesh", 500);
        TreeSet ts=new TreeSet();
        ts.add(e1);
        ts.add(e2);
        ts.add(e3);
        ts.add(e4);
        ts.add(e5);
        
    System.out.println(ts);
    
    
    TreeSet t=new TreeSet(new MyComparator5());
    t.add(e1);
    t.add(e2);
    t.add(e3);
    t.add(e4);
    t.add(e5);
    System.out.println(t);
    
        
        
    }


}
 







