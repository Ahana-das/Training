package collectionsEx;

import java.util.LinkedHashMap;

public class LinkedHashMapEx1 {
	public static void main(String[] args) {
		LinkedHashMap<Integer, String> hm = new LinkedHashMap<Integer,String>();
		LinkedHashMap hm1=new LinkedHashMap();
		
		hm.put(123,"ahana");
		hm.put(124,"sahana");
		hm.put(126,"areena");
		hm1.put("ab","diya"); 
		System.out.println(hm);
		System.out.println(hm1);
		System.out.println(hm.get(126));
		hm.replace(123, "agu");
		System.out.println(hm);
		




		
	}

}
