package collectionsEx;

import java.util.LinkedHashSet;
import java.util.TreeSet;

public class TreeSetEx {
	public static void main(String[] args) {
		TreeSet hs=new TreeSet();
		hs.add(12);
		hs.add(15);
		hs.add(12);
		hs.add(55);
		System.out.println(hs);
	}


}
