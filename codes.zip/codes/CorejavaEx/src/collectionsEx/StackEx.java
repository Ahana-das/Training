package collectionsEx;

import java.util.Stack;

public class StackEx {
	public static void main(String[] args) {
		Stack st=new Stack();
		st.push(12);
		st.push(25);
		st.push("ahana");
		System.out.println(st.peek());
		System.out.println(st.pop());
		System.out.println(st.peek());
	}

}
