package collectionsEx;

import java.util.Comparator;
import java.util.TreeSet;

class MyComparator1 implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		Integer i1=(Integer) o1 ;
		Integer i2=(Integer) o2;
		//return +ve when object1 has to come before object2
				//return -ve when object1 has to come after object2
				//return 0 when object1 & object2 are equal
		//1st way
		return -i1.compareTo(i2);
		
		//2nd way
		//return i2.compareTo(i1);
		
		//3rd way
		
		/*if(i1<i2)
			return +1;
		else if(i1>i2)
			return -1;
		else
			return 0;*/
	}
	
}

public class CompareEx {
	public static void main(String[] args) {
		TreeSet ts=new TreeSet(new MyComparator1());
		ts.add(15);
		ts.add(21);
		ts.add(1);
		System.out.println("set:" + ts);
	}

}
