package com.cap;

public class Exception2 {
	public static void main(String[] args) {
		try{
			int a[]= new int[5];
			a[4]= 30/2;
			String s= "welcome";
			int x=Integer.parseInt(s);
			System.out.println(s.length());
			System.out.println("no error " + a[4]+ " " + x);
			
			
		}catch(ArrayIndexOutOfBoundsException ae){
			System.out.println("please enter valid index");
		} catch(ArithmeticException e) {
			System.out.println("donot enter zero as denominator");
		} catch(NumberFormatException e) {
			System.out.println("String cannot be changed into integer" +e);
		} catch(Exception e){
			System.out.println("length cannot be found" +e);
		}
		finally{
			System.out.println("executes every time for closing connections");
		}
		System.out.println("remaining code executed");
	}

}
