package com.cap;

public class EncapsulationEx {
	public static void main(String[] args) {
		Employee1 obj=new Employee1();
		obj.setEmpid(12);
		System.out.println(obj.getEmpid());
		obj.setEname("Ahana");
		System.out.println(obj.getEname());
		obj.setEsal(15000);
		System.out.println(obj.getEsal());
		obj.setAtmpin(1234);
		
	}

}
