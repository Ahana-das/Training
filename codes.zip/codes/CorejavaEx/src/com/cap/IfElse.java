package com.cap;

/*case 1:
 * public class IfElse { 
	public static void main(String[] args) {
		int x=0;
		if(x)
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("hi");
		}
	}

}

case 2:
public class IfElse{
	public static void main(String[] args) {
		int x=10;
		if(x=20)
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("hi");
		}
	}
}
case 3:
public class IfElse{
	public static void main(String[] args) {
		
	int x=10;
	if(x==20)
		
	{
		System.out.println("hello");
	}
	else
	{
		System.out.println("hi"); 
	}
}
}
case 4:
	public class IfElse{

	public static void main(String[] args) {
		boolean x=true;
		if(x==false)
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("hi");
		}
	}
}
case 5:
public class IfElse{
public static void main(String[] args) {
	boolean x=false;
	if(x=false)
	{
		System.out.println("hello");
	}
	else
	{
		System.out.println("hi");
	}
}
} */


