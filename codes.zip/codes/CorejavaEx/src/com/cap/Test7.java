package com.cap;

public class Test7 {
	public Test7(){
		System.out.println("default constructor");
	}
	public Test7(String name){
		System.out.println("param constructor");
	}
	public Test7(int id, int b){
		System.out.println("int param constructor");
	}
	void m1(){
		System.out.println("method");
	}
	public static void main(String[] args) {
		Test7 t=new Test7("ahana");
		Test7 t1=new Test7(51,14);
		Test7 t2=new Test7();
		t.m1();
				
	}

}
