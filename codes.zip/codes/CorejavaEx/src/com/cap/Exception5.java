package com.cap;
class Exception1 extends Exception 
{   private  String name;

	 public Exception1(String name1)
	 {
		 this.name=name1;
	 }
	 public String toString(){
		 return "you need to have more than 8 characters";
	 }
}public class Exception5 {
	 static void validate(String name1) throws Exception1
	 {
		 if(name1.length()<8)
		 {
			 throw new Exception1(name1);
		 }
		 else
		 {
			 System.out.println("you have given correct characters");
		 }
	 }
	 public static void main(String[] args) throws Exception1 {
		Exception5.validate("ahanadas");
		System.out.println("rest of the code");
	}
	

}
