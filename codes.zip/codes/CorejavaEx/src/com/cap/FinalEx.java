package com.cap;

class Test9{
	int a=123;
	public void add()
	{
		a=++a;
		int b=11;
		System.out.println(a+b);
	}
}

public class FinalEx extends Test9 {
	public void add(){
		a=--a;
		int b=11;
		System.out.println(a+b);
	}
	public static void main(String[] args) {
		FinalEx obj=new FinalEx();
		obj.add();
	}
	

}
