package com.cap;

class A {
	void m1() {
		System.out.println("hello method 1");
	}
}


class B extends A {
	void m2() {
		System.out.println("hello method 2");
	}

	void m3() {
		System.out.println("hello method 3");
	}
}

class C extends A {
	void m4() {
		System.out.println("hello method 4");
	}

	void m5() {
		System.out.println("hello method 5");
	}
}

public class Inheritance extends C {
	public static void main(String[] args) {
		Inheritance t = new Inheritance();
		t.m1();
		t.m5();
	}

}
