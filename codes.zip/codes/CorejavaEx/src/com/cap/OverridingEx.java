package com.cap;
class Parent{
	void add1(){
		System.out.println("welcome honey");
	}
	void add(){
		System.out.println("welcome dear");
	}
	
}


public class OverridingEx extends Parent{
	void add(){
		System.out.println("welcome all");
	} 
	
	public static void main(String[] args) {
		OverridingEx obj=new OverridingEx();
		obj.add1();
		obj.add();
		
		
	}

}
