package com.cap;

public class StringBufferEx {
	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("welcome");
		StringBuffer sb1=new StringBuffer("welcome");
		System.out.println(sb.equals(sb1));
		
		
		String s=sb.toString();
		String s1=new String("welcome");
		System.out.println(s.equals(s1));
		
		
		
	}

}
