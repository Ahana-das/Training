package com.cap;
interface Test4{
	void m1();
	void m2();

}

public class InterfaceEx implements Test4 {
	public static void main(String[] args) {
		InterfaceEx obj=new InterfaceEx();
		obj.m1();
		obj.m2();
	}

	@Override
	public void m1() {
		System.out.println("welcome to method 1");
	}

	@Override
	public void m2() {
		System.out.println("welcome to method 2");
		
		
	}

	

}
