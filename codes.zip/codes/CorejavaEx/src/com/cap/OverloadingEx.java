package com.cap;
class Test6{
	static void add(){
		System.out.println("default value");
	}
	static void add(int a,int b){
		System.out.println("addition=" + (a+b));
	}
	static void add(int a,int b,int c){
		System.out.println("addition=" + (a+b+c));
	}
	static void add(float a,int b){
		System.out.println("addition=" + (a+b));
	}
	static void add(int a,float b){
		System.out.println("addition=" + (a+b));
	}
}

public class OverloadingEx {
	public static void main(String[] args) {
		Test6.add();
		Test6.add(12,15);
		Test6.add(12,15,18);
		Test6.add(12.5f,17);
		Test6.add(18,12.5f);
	}

}
