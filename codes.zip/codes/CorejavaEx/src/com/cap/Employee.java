package com.cap;

import java.util.Scanner;

public class Employee {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee name:");
		String a=sc.next();
		a+=sc.nextLine();
		System.out.println("Enter Employee id:");
		int b=sc.nextInt();
		System.out.println("Enter Employee salary:");
		int c=sc.nextInt();
		System.out.println("Enter Employee address:");
		String d=sc.next();
		System.out.println("name:" + a + "\n" + "id:" + b + "\n" + "salary:" + c + "\n" + "address:" + d);
		sc.close();
	}

}
