package com.cap;
class Test //instance and static difference
{
int var1=123; //instance variable
static int var2=1234; //static variable
void m1() //instance method
{
	System.out.println("instance method of test class");
}
static void m2() //static method
{
	System.out.println("static method of test class");
}
public static void main(String args[])
{
	Test.m2();
	Test tes=new Test(); //object creation
	tes.m1();
tes.m1();
	Test.m2();
}
}
