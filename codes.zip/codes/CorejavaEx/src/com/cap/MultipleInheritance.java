package com.cap;

abstract class Test2 {
	void m1() {
		System.out.println("hello method 1");
	}
	abstract void m2();
}
public class MultipleInheritance extends Test2 {
	public static void main(String[] args) {
		MultipleInheritance t = new MultipleInheritance();
		t.m1();
		t.m2();
		
	}

	@Override
	void m2() {
		System.out.println("Wecome to Test Class m3 method");
	}

}