package com.cap;

public class ExceptionHandling1 {
	public static void main(String[] args) {
		try{
			int a1=10;
			int b=0;
			int c=a1/b;
		}catch(ArithmeticException ae){
			System.out.println("dont enter zero as denominator");
			//System.out.println(ae);
			//ae.printStackTrace();
			//System.out.println(ae.getMessage());
		}
		
		try{
			int a[]=new int[5];
			a[0]=1;
			a[1]=2;
			a[2]=3;
			a[4]=5;
			for(int i=0;i<a.length;i++){
				System.out.println(a[i]);
			}
		}catch(ArrayIndexOutOfBoundsException ae){
				System.out.println(ae);
			
		}
	
	
	

	}
}
