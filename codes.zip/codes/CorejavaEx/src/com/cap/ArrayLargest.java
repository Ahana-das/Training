package com.cap;

import java.util.Scanner;

public class ArrayLargest {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number of elements");
		int n= sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the elements");
		for(int i=0;i<n;i++){
			a[i]=sc.nextInt();
		}
		int max=a[0];
		for(int i=0;i<n;i++)
		{
			if(max<a[i]){
				max=a[i];
			}
		}
		System.out.println("the largest number is "+ max);
		
	}

}
