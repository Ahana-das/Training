package com.cap;

class Exception8 extends Exception 
 {   private int age;
 
	 public Exception8(int age1)
	 {
		 this.age=age1;
	 }
	 public String toString(){
		 return "you are not eligible to vote";
	 }
 }
 public class ExceptionUser
 {
	 static void validation(int age1) throws Exception8
	 {
		 if(age1<18)
		 {
			 throw new Exception8(age1);
		 }
		 else
		 {
			 System.out.println("you are eligible to vote");
		 }
	 }
	 public static void main(String[] args) throws Exception8{
		ExceptionUser.validation(16);
		
	}
 }
 
	 