package com.cap;

public class StringEx {
	public static void main(String[] args) {
		String s1="shubham";
		String s2=new String("shubham");
		System.out.println(s1.equals(s2));
		System.out.println(s1==s2);
		
		String s3="hello";
		String s4="hallo";
		System.out.println(s3.compareTo(s4));
		System.out.println("as".equals("as"));
		System.out.println(s1.concat(s2));
		System.out.println(s3.intern());
		System.out.println(s1.replace("h", "j"));
		System.out.println(s3.replace(s2, s4));
	
		System.out.println(s4.replaceAll(s2, s1));
		System.out.println(s1.codePointAt(0));
		System.out.println(s1.toLowerCase());
		System.out.println(s1.length());
		System.out.println(s2.indexOf(s3));
		System.out.println(s3.hashCode());
		System.out.println(s4.length());
		System.out.println(s1.trim());
		

}
}