package com.cap;

public class Exception3 {
	public static void main(String[] args) {
		try {            int c=12/4;
		                 System.out.println(c);
							try {
								System.out.println("Division");
								int b=30/2;
								System.out.println(b);
							    }catch (ArithmeticException e) {
								System.out.println(e);
							    }
							try{
								int a[] = new int[3];
								a[3]=4;
								
							   }catch (ArrayIndexOutOfBoundsException e){
								   System.out.println(e);
							   }finally
							{
								   System.out.println("always execute finally block");
							}
							System.out.println("remaining try statements");
							
			
		} catch (Exception e) {
			System.out.println("handled");
		}
		System.out.println("normal execution");
	}

}
