package com.cap;

public class SwitchChoice {
	public static void main(String[] args) {
		/*
		 //case 1:
		 int x=10;
		int y=20;
		switch(x)
		{
		case 10:
		System.out.println(10);
		break;
		case y:
		System.out.println(20);
		break;
		}
		//case 2:
		byte b=10;
		switch(b)
		{
		case 10:
			System.out.println("10");
			break;
		case 100:
			System.out.println("100");
			break;
		case 1000:
			System.out.println("1000");
			break;
		}
		//case 3:
		int x=10;
		switch(x)
		{
		case 97:
			System.out.println("97");
		case 98:
			System.out.println("98");
		case 97:
			System.out.println("97");
		}
			//case 4:
		int x=1;
		 switch(x)
		 {
		 default:
			 System.out.println("def");
			 break;
		 case 0:
			 System.out.println("0");
			 break;
		 case 1:
			 System.out.println("1");
			 break;
		 }*/
	}

}
