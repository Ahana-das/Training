package com.cap;

import java.util.Scanner;

public class ExceptionHandlingEx {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the numerator");
		int num=sc.nextInt();
		System.out.println("Enter the denominator");
		int den=sc.nextInt();
		try{
		int ans= num/den;
		System.out.println("the answer is+" + ans);
		}catch(ArithmeticException ae)
		{
			System.out.println("dont enter zero as denominator");
		}
		sc.close();
	}

}
