package com.cap;

import com.cap1.Test1;

class Test10 {
	public static void main(String[] args) {
		Test1 t=new Test1();
		System.out.println(t.eid);
	}
 }
	 
