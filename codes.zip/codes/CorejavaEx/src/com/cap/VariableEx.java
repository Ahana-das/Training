package com.cap;
class VariableEx
{
static int x=20;
static int y=10;
static void addTwo()
	{
		int a=125;
		int b=105;
		int c=a+b;
		System.out.println("addition of two numbers"+c);
		System.out.println("addition of two numbers"+(x+y));
	}
static void subTwo()
	{
		int a=125;
		int b=105;
		int c=a-b;
		System.out.println("sub of two numbers"+c);
		System.out.println("sub of two numbers"+(x-y));
	}
static int subTwo1(int a,int b)
	{
		return a-b;
	}
public static void main(String args[])
{
	VariableEx.addTwo();
	VariableEx.subTwo();
	System.out.println(VariableEx.subTwo1(10,30)); //param-method
	int sub=VariableEx.subTwo1 (100,90);
	int val=sub+1000;
	System.out.println(sub);
	System.out.println(val);
	System.out.println("Welcome to java");
}

}