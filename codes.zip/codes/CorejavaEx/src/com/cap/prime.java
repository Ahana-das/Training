package com.cap;

public class prime {
	public static void main(String[] args) {
		int a = 15;
		int flag=1;
		for (int i = 2; i < a; i++) {
			if (a % i == 0) {
				flag=0;
			}
		}
			if(flag==0){
				System.out.println("Not prime number");
			}
			else{
				System.out.println("prime number");
			}
			
		
	}
}
