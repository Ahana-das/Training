package com.cap;

public class Employee1 {
	 
	
		private int empid;
		private String ename;
		private int esal;
		private int atmpin;
		public int getEmpid() {
			return empid;
			
		}
		public void setEmpid(int empid) {
			this.empid = empid;
		}
		public String getEname() {
			return ename;
		}
		public void setEname(String ename) {
			this.ename = ename;
		}
		public int getEsal() {
			return esal;
		}
		public void setEsal(int esal) {
			this.esal = esal;
		}
		
		public void setAtmpin(int atmpin) {
			this.atmpin = atmpin;
		}
		
	
	
		
		
	
	}


