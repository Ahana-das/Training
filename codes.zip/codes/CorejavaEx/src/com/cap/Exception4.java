package com.cap;

public class Exception4 {
	public static void main(String[] args) {
		try {
			System.out.println("welcome");
			int a=25/5;
			System.out.println(a);
			System.exit(0);
		} finally {
			System.out.println("bye bye");
			
		}
	}

}
