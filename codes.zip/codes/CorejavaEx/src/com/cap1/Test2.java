package com.cap1;
class Parent
{
	static int id=123;
	public Parent(){
		this(12);
		System.out.println("default constructor of parent");
	}
	public Parent(int a){
		System.out.println("param constructor" +a);
	}
	void m1()
	{
		System.out.println("parent class method");
	}
	void m4(){
		System.out.println("hello core java");
	}
}

public class Test2 extends Parent {
	static int id=890;
	public Test2()
	{
		super();
		System.out.println(this.id);
		System.out.println(super.id);
		this.m1();
		super.m1();
		System.out.println(this);
		System.out.println("default constructor of child ");
	}
	void m1(){
		System.out.println("child class method");
	}
	void m3(){
		System.out.println("hello java");
	}
	public static void main(String[] args) {
		Test2 t=new Test2();
		t.m3();
		t.m4();
		
	}
}
