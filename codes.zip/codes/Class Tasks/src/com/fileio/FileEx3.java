package com.fileio;

import java.io.File;
import java.io.IOException;

public class FileEx3 {
	public static void main(String[] args) throws IOException {
		File f=new File("myfolder1/myfolder2/myfile.txt");
		f.getParentFile().mkdirs();
		f.createNewFile();
		System.out.println("done" + f.getAbsolutePath());
		System.out.println(f.getPath());
		System.out.println(f.setReadOnly());
		System.out.println(f.delete());

	}

}
