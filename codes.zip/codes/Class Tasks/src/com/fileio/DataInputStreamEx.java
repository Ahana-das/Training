package com.fileio;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataInputStreamEx {
	public static void main(String[] args) throws IOException {
		FileOutputStream fs = new FileOutputStream("hello.txt");
		DataOutputStream dos = new DataOutputStream(fs);
		
		dos.writeInt(10);
		dos.writeUTF("ahana");
		
		FileInputStream fs1 = new FileInputStream("hello.txt");
		DataInputStream dis = new DataInputStream(fs1);

		System.out.println("Int :" + dis.readInt());
		System.out.println("String :" + dis.readUTF());
	}

}
