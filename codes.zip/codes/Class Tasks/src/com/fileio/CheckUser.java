package com.fileio;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class CheckUser {
	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your username");
		String username=sc.next();
		
		System.out.println("enter your password");
		String password=sc.next();
		
		FileReader fr1=new FileReader("check.txt");
		BufferedReader br=new BufferedReader(fr1);
		String username1=br.readLine();
		String password1=br.readLine();
		if(username.equals(username1)&&password.equals(password1))
		{
			System.out.println("Login Success");
		}
		else
			System.out.println("Please enter valid credentials");
	}

}
