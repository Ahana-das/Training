package com.fileio;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class ForCheckUser {
		public static void main(String[] args) throws IOException {
			PrintWriter out=new PrintWriter("Check.txt");
					out.println("capgemini");
					out.println("capgemini123");
					
			out.flush();
			out.close();				
	}

}
