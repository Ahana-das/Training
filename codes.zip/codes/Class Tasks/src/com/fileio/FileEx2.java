package com.fileio;

import java.io.File;
import java.io.IOException;

public class FileEx2 {
	public static void main(String[] args) throws IOException {
		File f=new File("myfolder/myfile.txt");
		f.getParentFile().mkdir();
		f.createNewFile();
		System.out.println("done");
	}

}
