package com.fileio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class CheckMultiUser {
	public static void main(String[] args) throws IOException {
		
	   int flag=0;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter your username");
		String username=sc.next();
		System.out.println("enter your password");
		String password=sc.next();
		
		FileReader fr1=new FileReader("check.txt");
		BufferedReader br=new BufferedReader(fr1);
		
		//String username1=br.readLine();
		//String password1=br.readLine();
		try{
			while(fr1 != null) {
		
		if(username.equals(br.readLine().toString()) && password.equals(br.readLine().toString()))
		{
		            flag=1;
					break;
		}
	}
			if(flag==1)
			{
				System.out.println("correct");
			}
		}
		catch(Exception e)
		{
			System.out.println("username and password are incorrect");
		}
		br.close();
	}
}
		
	
	




