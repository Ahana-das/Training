package com.fileio;

import java.io.IOException;
import java.io.PrintWriter;

public class PrintWriterEx {
	public static void main(String[] args) throws IOException {
		PrintWriter out=new PrintWriter("cap4.txt");
				out.println(1000);
				out.println(false);
				out.println("ahana");
				
		out.flush();
		out.close();
	}
	

}



