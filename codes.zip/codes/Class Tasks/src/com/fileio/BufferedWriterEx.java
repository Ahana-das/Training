package com.fileio;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterEx {
	public static void main(String[] args) throws IOException {
		FileWriter fw=new FileWriter("cap3.txt");
		BufferedWriter bw=new BufferedWriter(fw);
				bw.write(97);
				bw.newLine();
				bw.write("sandeep \n intellect");
				bw.write("\n");
				char [] ch1={'a' , 'b' , 'c'};
				bw.write(ch1);
				bw.newLine();
		fw.flush();
		fw.close();
		bw.close();
	}
	

}
