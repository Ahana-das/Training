package com.fileio;

import java.util.Scanner;

public class CheckUserFile {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your username");
		String username=sc.next();
		
		System.out.println("enter your password");
		String password=sc.next();
		if(username.equals("capgemini")&&password.equals("capgemini123"))
		{
			System.out.println("Login Success");
		}
		else
			System.out.println("Please enter valid credentials");
	}

}



