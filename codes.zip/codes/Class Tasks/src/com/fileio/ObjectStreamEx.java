package com.fileio;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Employee implements Serializable {
	private int stdid;
	private String name;
	private int salary;
	public int getStdid() {
		return stdid;
	}
	public void setStdid(int stdid) {
		this.stdid = stdid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}

}
 public class ObjectStreamEx{
	 public static void main(String[] args) throws IOException {
		Employee employee =new Employee();
		employee.setStdid(12);
		employee.setSalary(15000);
		employee.setName("ahana");
		FileOutputStream fos = new FileOutputStream("capgemini1.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(employee);
		System.out.println("success");
		
	}
 }
