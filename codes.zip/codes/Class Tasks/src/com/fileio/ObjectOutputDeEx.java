package com.fileio;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectOutputDeEx  {
	public static void main(String[] args) throws Exception{
		FileInputStream fis=new FileInputStream("capgemini1.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
	    Employee emp = (Employee) ois.readObject(); //typecasting
	    System.out.println(emp.getSalary());
	    System.out.println(emp.getStdid());
	    System.out.println(emp.getName());
		
	}

}
