package com.fileio;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderEx {
	public static void main(String[] args) throws IOException {
		FileReader fr1=new FileReader("cap4.txt");
		int i=fr1.read();
		while(i != -1)
		{
			System.out.println((char) i); //typecasting
			i=fr1.read();
		}
		
	}

}
