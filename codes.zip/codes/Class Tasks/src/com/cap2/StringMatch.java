package com.cap2;

public class StringMatch {
	

		public static void main(String[] args) 
		{
			String s1 ="Ahana";
			
			String s2 ="Ahana";
			System.out.println(s1.matches(s2));
         }
    }


