package com.cap2;

public class Contents {
	
	    public static void main(String[] args) {
	        String s1="Ahana Das";
	        String s2="Ahana Das";
	        System.out.println(s1.endsWith(s2));
	    }

	 

	}
	 


