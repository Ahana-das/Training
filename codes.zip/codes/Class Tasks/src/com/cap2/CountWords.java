package com.cap2;
import java.util.Scanner;

public class CountWords 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any sentence: ");
		String a=sc.nextLine();
		
			String s[]= a.split("\\s+");            //"\\s+" is a regular expression
			System.out.println("The numbers of words present in this sentence is: "+ s.length);
		    
		sc.close();
	}
}