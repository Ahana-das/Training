package com.cap.service;

import com.cap.bean.Employee;
import com.cap.dao.EmployeeDao;
import com.cap.dao.EmployeeDaoImp;

public class EmployeeServiceImp implements EmployeeService {
	EmployeeDao dao = new EmployeeDaoImp();		

	@Override
	public void insertEmployee(Employee employee) {
		dao.insertEmployee(employee);
	}

	@Override
	public Employee retrieveEmployee(Integer empId) {//subclass of interface needed for implementing the abstract methods
		Employee emp = dao.retrieveEmployee(empId);
		return emp;
	} 
}
