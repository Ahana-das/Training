package com.cap.service;

import com.cap.bean.Employee;

public interface EmployeeService { //Interface
	void insertEmployee(Employee employee);
	Employee retrieveEmployee(Integer eid); //return type is Employee information basede on id
	
}
