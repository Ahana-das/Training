package com.cap.dao;

import java.util.HashMap;
import java.util.Map;

import com.cap.bean.Employee;

public class EmployeeDaoImp implements EmployeeDao { //subclass of inteface
	Map<Integer , Employee> employees = new HashMap<Integer , Employee>();

	@Override
	public void insertEmployee(Employee employee) {
		employees.put(employee.getEmpId(), employee);
	}

	@Override
	public Employee retrieveEmployee(Integer empId) {
		Employee emp=employees.get(empId);
		return emp;
	} 
}
