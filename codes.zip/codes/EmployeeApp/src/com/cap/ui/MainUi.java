package com.cap.ui;

import java.util.Scanner;

import com.cap.bean.Employee;
import com.cap.service.EmployeeService;
import com.cap.service.EmployeeServiceImp;

public class MainUi {
	static EmployeeService service = new EmployeeServiceImp(); // we are givinng the reference to the interface but creating the object pf subclass to hide the data
	static Scanner scanner=new Scanner(System.in);

	public static void main(String[] args) {
		
		
		while(true){
			System.out.println("\n\n\nWelcome to the application");
			System.out.println("1.Create Employee");
			System.out.println("2.select Employee");
			System.out.println("3.exit");
			System.out.println("Enter your choice");
			 int a= scanner.nextInt();
		        switch(a)
		        {
		            case 1:
		            	
		        		System.out.println("Enter the employee id :");
		        		int empId= scanner.nextInt();
		        		System.out.println("Enter the employee name :");
		        		String empName = scanner.next();
		        		System.out.println("Enter the salary :");
		        		int empSal = scanner.nextInt();
		        		
		        		Employee employee = new Employee();
			    		employee.setEmpId(empId);
			    		employee.setEmpName(empName);
			    		employee.setEmpSal(empSal);
			    		
			    		service.insertEmployee(employee);
			    		System.out.println("****CONGRATULATIONS! EMPLOYEE INSERTED****");
			            
		        		break;
		            
		            case 2:
		            	System.out.println("Fetching Employee");

		            	System.out.println("Enter the employee id :");
		        		int empId1= scanner.nextInt();
		            	Employee emp = service.retrieveEmployee(empId1);
		        		System.out.println(emp);
		        		break;
		        		
		            case 3:
		            	System.out.println("Thank you. Have a nice day .");
		            	System.exit(0);
		            	
		            default:
		            	System.out.println("You have entered wrong choice . Please enter correct choice");

		        }
		}
		
		
		
		
		
		
		
		
		
	}
}
