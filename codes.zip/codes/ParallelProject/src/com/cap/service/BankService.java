package com.cap.service;

import java.util.List;

import com.cap.bean.BankDetail;
import com.cap.bean.BankTransaction;

public interface BankService { 
	void insertBankDetails(BankDetail bank);

	BankDetail showBalance(Long accountno);

	int depositMoney(long accountno, int depositMoney);

	int withrawMoney(long accountno, int withdrawMoney);

	long transferFunds(long firstAccount, long secondAccount, int transferAmount);

	List<BankTransaction> printTransaction();
	
	boolean isOkayName(String name);
	boolean isOkayNumber(long mobileno);
	boolean accountTypeValidate(String accountType);

}
