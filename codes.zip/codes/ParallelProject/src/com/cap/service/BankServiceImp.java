package com.cap.service;

import java.util.List;

import com.cap.bean.BankDetail;
import com.cap.bean.BankTransaction;
import com.cap.dao.BankDao;
import com.cap.dao.BankDaoImp;

public class BankServiceImp implements BankService { //BankServiceImp is the child class of the interface BankService

	BankDao dao = new BankDaoImp(); //Creating an object of BankDao class

	@Override
	public void insertBankDetails(BankDetail bank) {
		dao.insertBankDetails(bank); //calling the method of Dao class
	}

	@Override
	public BankDetail showBalance(Long accountno) {
		BankDetail bankers = dao.showBalance(accountno); //calling the method of Dao class
		return bankers;
	}

	@Override
	public int depositMoney(long accountno, int depositAmount) {
		int balance = dao.depositMoney(accountno, depositAmount); //calling the method of Dao class
		return balance;

	}

	@Override
	public int withrawMoney(long accountno, int withdrawAmount) {
		int remainingBalance = dao.withdrawMoney(accountno, withdrawAmount); //calling the method of Dao class
		return remainingBalance;
	}

	@Override
	public long transferFunds(long firstAcc, long secondAcc, int transferAmount) {
		long remainingBal = dao.transferFunds(firstAcc, secondAcc, transferAmount); //calling the method of Dao class
		return remainingBal;
	}

	@Override
	public List<BankTransaction> printTransaction() {
		List<BankTransaction> printTransact = dao.printTransaction();//calling the method of Dao class
		return printTransact;
	}

	@Override
	public boolean isOkayName(String name) { //validation implementation for names to be alphabets starting with capital letter
		if(name.matches("[A-Z][a-zA-Z]*"))
			return true;
		else
			return false;
	}

	@Override
	public boolean isOkayNumber(long mobileno) { //validation implementation for mobile numbers to be 10 digits only and starting with 6-9
		String mob= Long.toString(mobileno);
		if (mob.matches("[6-9][0-9]{9}"))
		return true;
		else
			return false;
	}

	@Override
	public boolean accountTypeValidate(String accountType) { //validation implementation for the account type to be savings or current only
		if(accountType.equalsIgnoreCase("savings") || accountType.equalsIgnoreCase("current"))
			return true;
		else
		return false;
	}

}
