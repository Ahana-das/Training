package com.cap.bean;

public class BankDetail { 
	private String name;
	private String branch;
	private long mobileno;
	private String accountType;
	private long accountno;
	private long balance;

	@Override
	public String toString() {
		return "BankDetail [name=" + name + ", branch=" + branch + ", mobileno=" + mobileno + ", accountType="
				+ accountType + ", accountno=" + mobileno + ", balance=" + balance + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public long getMobileno() {
		return mobileno;
	}

	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public long getAccountno() {
		return accountno;
	}

	public long setAccountno(long accountno) {
		return this.accountno = accountno;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

}
