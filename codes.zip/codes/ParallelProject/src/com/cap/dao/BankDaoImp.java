package com.cap.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cap.Exception.AccountNotFoundException;
import com.cap.bean.BankDetail;
import com.cap.bean.BankTransaction;

public class BankDaoImp implements BankDao {
	Map<Long, BankDetail> bankdetail = new HashMap<Long, BankDetail>(); //creating map for storing details
	Map<BankTransaction, Long> printTrans = new HashMap<BankTransaction, Long>();

	@Override //storing informations into the map
	public void insertBankDetails(BankDetail bank) { //Implementation of the method called in service class
		bankdetail.put(bank.getAccountno(), bank);

	}

	@Override //
	public BankDetail showBalance(Long accountno) { //Implementation of the method called in service class
		BankDetail bankers = bankdetail.get(accountno); // retrieving information from map using get
		if(bankers==null){
			throw new AccountNotFoundException("Sorry ! No account found  . Please Enter a valid Account Number . ThankYou ");
		}
		return bankers;
	}

	@Override
	public int depositMoney(long accountno, int depositAmount) { //Implementation of the method called in service class
		BankDetail bal = bankdetail.get(accountno); //retrieving the balance amount from map using get
		if(bal==null){
			throw new AccountNotFoundException("Sorry ! No account found  . Please Enter a valid Account Number . ThankYou ");
		}
		long previousBal = bal.getBalance();
		long newBal = previousBal + depositAmount;
		bal.setBalance(newBal);
		BankTransaction bankTran = new BankTransaction();
		bankTran.setTid(12);
		bankTran.setNewBalance(newBal);
		bankTran.setOldBalance(previousBal);
		bankTran.setFromAccount(accountno);
		bankTran.setTranstype("Credited");

		printTrans.put(bankTran, accountno);
		System.out.println("Credited succesfully " + printTrans.size());
		
		return (int) newBal;
	}

	@Override
	public int withdrawMoney(long accountno, int withdrawAmount) { //Implementation of the method called in service class
		BankDetail bal = bankdetail.get(accountno); //retrieving the balance amount from map using get
		if(bal==null){
			throw new AccountNotFoundException("Sorry ! No account found  . Please Enter a valid Account Number . ThankYou ");
		}
		double prevBal = bal.getBalance();
		double remainingBal = prevBal - withdrawAmount;
		BankTransaction bankTran = new BankTransaction();
		bankTran.setTid(12);
		bankTran.setNewBalance(remainingBal);
		bankTran.setOldBalance(prevBal);
		bankTran.setFromAccount(accountno);
		bankTran.setTranstype("Debitted");

		printTrans.put(bankTran, accountno);
		System.out.println("Debitted succesfully " + printTrans.size());

		return (int) remainingBal;
	}

	@Override
	public long transferFunds(long firstAcc, long secondAcc, int transferAmount) { //Implementation of the method called in service class
		BankDetail first = bankdetail.get(firstAcc);
		if(first==null){
			throw new AccountNotFoundException("Sorry ! No account found  . Please Enter a valid Account Number . ThankYou ");
		}
		BankDetail second = bankdetail.get(secondAcc);
		if(second==null){
			throw new AccountNotFoundException("Sorry ! No account found  . Please Enter a valid Account Number . ThankYou ");
		}
		long firstBalance = first.getBalance();
		long secondBalance = second.getBalance();
		long firstBalRemaining = firstBalance - transferAmount;
		long secondBalRemaining = secondBalance + transferAmount;
		if(firstBalance < transferAmount){
			System.out.println("Insuficient balance ");
			System.exit(0);
		}
		first.setBalance(firstBalRemaining);
		second.setBalance(secondBalRemaining);

		BankTransaction bankTran = new BankTransaction();
		bankTran.setTid(12);
		bankTran.setNewBalance(firstBalRemaining);
		bankTran.setOldBalance(firstBalance);
		bankTran.setFromAccount(firstAcc);
		bankTran.setToAccount(secondAcc);
		bankTran.setTranstype("Fund Transfered");

		printTrans.put(bankTran, firstAcc);
		System.out.println("Transfer succesfully " + printTrans.size());
		return firstBalRemaining;
	}

	@Override
	public List<BankTransaction> printTransaction() { //Implementation of the method called in service class
		List<BankTransaction> list = new ArrayList<BankTransaction>(printTrans.keySet());
		return list;
	}

}
