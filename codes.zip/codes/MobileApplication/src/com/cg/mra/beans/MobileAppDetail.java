package com.cg.mra.beans;

public class MobileAppDetail {
	private String accountType;
	private String custName;
	private double balance;
	
	public MobileAppDetail(String accountType, String custName, double balance) {
		super();
		this.accountType = accountType;
		this.custName = custName;
		this.balance = balance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
}
