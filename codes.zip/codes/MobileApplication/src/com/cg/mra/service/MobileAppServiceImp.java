package com.cg.mra.service;

import com.cg.mra.beans.MobileAppDetail;
import com.cg.mra.dao.MobileAppDao;
import com.cg.mra.dao.MobileAppDaoImp;

public class MobileAppServiceImp implements MobileAppService {
	MobileAppDao dao = new MobileAppDaoImp();
	@Override
	public MobileAppDetail balanceEnquiry(Long mobileno) { 
		MobileAppDetail detail = dao.balanceEnquiry(mobileno); //calling the method of Dao class
		return detail;
	}

	@Override
	public int mobileRecharge(long mobileno, int recharge) {
		int bal = dao.mobileRecharge(mobileno, recharge); //calling the method of Dao class
		return bal;
	}
	public boolean isOkayNumber(long mobileno) { //validation of mobile number
		String mob= Long.toString(mobileno);
		if (mob.matches("[6-9][0-9]{9}"))
		return true;
		else
			return false;
	}

	@Override
	public boolean isOkayRecharge(int recharge) { //validation of recharge amount
		if(recharge!=0)
		return true;
		else
		return false;
	}
}
