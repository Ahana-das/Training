package com.cg.mra.service;

import com.cg.mra.beans.MobileAppDetail;

public interface MobileAppService {
	MobileAppDetail balanceEnquiry( Long mobileno);
	
	int mobileRecharge( long mobileno , int recharge );
	boolean isOkayNumber(long mobileno);
	boolean isOkayRecharge(int recharge);

}
