package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.MobileAppDetail;
import com.cg.mra.dao.MobileNoNotFoundException;
import com.cg.mra.service.MobileAppService;
import com.cg.mra.service.MobileAppServiceImp;

public class MobileAppMain {
	static MobileAppService service = new MobileAppServiceImp();
	static Scanner scanner=new Scanner(System.in);

	public static void main(String[] args) {
		
		
		while(true){
			System.out.println("\n\n\nWelcome to the mobile recharge application");
			System.out.println("1. Account Balance Enquiry");
			System.out.println("2. Recharge Account");
			System.out.println("3. Exit");
			
			System.out.println("Enter your choice");
			 int a= scanner.nextInt();
		        switch(a)
		        {
		        case 1 : //case1 for showing account details
		        	try{
		        		boolean isOkNumber = false;

		        	System.out.println("Enter the mobile no");
		        	long mobileno1;
		        	do{ //for validation of mobile numbers
	        			mobileno1=scanner.nextLong();
	        			isOkNumber = service.isOkayNumber(mobileno1);
	        			
	        			if(!isOkNumber){
	        				System.out.println("Please Enter 10 digits number only");
	        				System.out.println("Enter the mobile number");

	        			}
	        		} while(!isOkNumber);

		    		MobileAppDetail detail= service.balanceEnquiry(mobileno1);
	            	System.out.println("your balance is:" + detail.getBalance());
		        	}catch(MobileNoNotFoundException e){ //exception handling
		        		System.out.println(e.getMessage());
		        	}
	            	break;
		        	
		        	
		        case 2 : //case2 for recharging balance
		        	try{ 
		        	boolean isOkRecharge = false;
		        	System.out.println("Enter the mobile no");
		        	long mobileno2 = scanner.nextLong();
		        	System.out.println("Enter Recharge Amount");
		        	int recharge;
		        	do{ //for validation of recharging amount
	        			recharge=scanner.nextInt();
	        			isOkRecharge = service.isOkayRecharge(recharge);
	        			
	        			if(!isOkRecharge){
	        				System.out.println("Please Enter valid recharge amount");
	        				
	        			}
	        		} while(!isOkRecharge);
		        	
		        	int rechargeAmount = service.mobileRecharge(mobileno2, recharge);
	            	System.out.println("your new balance is:" + rechargeAmount);
		        	}catch(MobileNoNotFoundException e){ //Exception handling 
		        		System.out.println(e.getMessage());
		        	}
	            	break;
		        case 3 : //case3 for exiting
		        	System.out.println("Thank you. Have a nice day .");
	            	System.exit(0);
	            	break;
		}
}
	}
}
