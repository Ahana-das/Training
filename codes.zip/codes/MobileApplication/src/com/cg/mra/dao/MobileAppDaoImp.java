package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.MobileAppDetail;




public class MobileAppDaoImp implements MobileAppDao {
	Map<Long , MobileAppDetail> mobiledetail; //using map for storing details
	
	public MobileAppDaoImp(){
		mobiledetail= new HashMap<>();
		mobiledetail.put(8694759468l, new MobileAppDetail("prepaid","vaishali",200));
		mobiledetail.put(8697459552l, new MobileAppDetail("prepaid","ahana",500));
		mobiledetail.put(8697459450l, new MobileAppDetail("prepaid","shalinii",800));
		mobiledetail.put(8697459660l, new MobileAppDetail("prepaid","raju",800));
		mobiledetail.put(8697459488l, new MobileAppDetail("prepaid","tushar",400));	

	}
	@Override
	public MobileAppDetail balanceEnquiry(Long mobileno) {
		MobileAppDetail detail= mobiledetail.get(mobileno);  //Implementation of the method called in service class
		if(detail==null)
		{
			throw new MobileNoNotFoundException("ERROR : Given Account Id doesnot exist.");
		}
		return detail;
	}

	@Override
	public int mobileRecharge(long mobileno, int recharge) {
		MobileAppDetail detail = mobiledetail.get(mobileno);  //Implementation of the method called in service class
		if(detail==null)
		{
			throw new MobileNoNotFoundException("ERROR : Cannot Recharge Account as Given Mobile no Does Not exists.");
		}
		double oldBal= detail.getBalance();
		double newBal= oldBal + recharge;
		detail.setBalance(newBal);
		return (int) newBal;
	}


}
