package com.cg.mra.dao;

import com.cg.mra.beans.MobileAppDetail;

public interface MobileAppDao {
MobileAppDetail balanceEnquiry( Long mobileno);
	

	int mobileRecharge(long mobileno, int recharge);
	

}
