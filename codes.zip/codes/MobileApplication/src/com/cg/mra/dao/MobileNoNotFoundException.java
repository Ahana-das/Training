package com.cg.mra.dao;

public class MobileNoNotFoundException extends RuntimeException {
		public MobileNoNotFoundException(String errMsg) {
			super(errMsg);
		}
		
}
