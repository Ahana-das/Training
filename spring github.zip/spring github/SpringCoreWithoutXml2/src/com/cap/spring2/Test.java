package com.cap.spring2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(ApplicationConfig.class);
		Object obj= context.getBean("getEmp",Employee.class);
		Employee e=(Employee) obj;
		e.setEid(12);
		e.setEname("ahana");
		e.display();
	}

}
