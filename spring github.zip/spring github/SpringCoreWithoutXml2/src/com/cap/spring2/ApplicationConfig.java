package com.cap.spring2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfig {
	@Bean("getEmp")
	public Employee getEmployee()
	{
		return new Employee();
		
	}

}
