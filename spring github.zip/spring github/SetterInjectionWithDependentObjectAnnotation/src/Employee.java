import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	private int eid;
	private String ename;
	private int esal;
	@Autowired
	private Address add;
	
	
	
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int esal) {
		this.esal = esal;
	}
	 public void display()
	 {
		 System.out.println(eid);
		 System.out.println(ename);
		 System.out.println(esal);
		 System.out.println(add);
		 
	 }
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esal=" + esal + ", add=" + add + "]";
	}
	

}
