
public class Employee {
	private int eid;
	private String ename;
	private int esal;
	private Address add;
	private TAddress tad;
	public TAddress getTad() {
		return tad;
	}
	public void setTad(TAddress tad) {
		this.tad = tad;
	}
	
	public Address getAdd() {
		return add;
	}
	public void setAdd(Address add) {
		this.add = add;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int esal) {
		this.esal = esal;
	}
	 public void display()
	 {
		 System.out.println(eid);
		 System.out.println(ename);
		 System.out.println(esal);
		 System.out.println(add);
		 System.out.println(tad);
	 }
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esal=" + esal + ", add=" + add + ", tad=" + tad + "]";
	}
	

}
