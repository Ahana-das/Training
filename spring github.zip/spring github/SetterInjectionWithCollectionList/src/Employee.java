
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Employee {
	private int eid;
	private String ename;
	private int esal;
	private List<String> address;
	
	
	public List<String> getAddress() {
		return address;
	}
	public void setAddress(List<String> address) {
		this.address = address;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int esal) {
		this.esal = esal;
	}
	 public void display()
	 {
		 System.out.println(eid);
		 System.out.println(ename);
		 System.out.println(esal);
		 Iterator itr=address.iterator();
	        while (itr.hasNext()) {
	            System.out.println(itr.next()+" ");
	           
	        }
	 }
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esal=" + esal + ", address=" + address + "]";
	}
	
	
}
