
public class Person {

	private String firstname;
	private String lastname;
	private Address address;
	public Person(String firstname, String lastname, Address address) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.address = address;
	}
	@Override
	public String toString() {
		return "Person [firstname=" + firstname + ", lastname=" + lastname + ", address=" + address + "]";
	}
	
	 public void display()
	 {
		 System.out.println(firstname);
		 System.out.println(lastname);
		 
		 System.out.println(address);
	 }
}
