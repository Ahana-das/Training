package com.cap.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("empobj")
public class Employee {
	private int eid;
	private String ename;
	@Autowired
	private Address add;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	public Address getAdd() {
		return add;
	}
	public void setAdd(Address add) {
		this.add = add;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + "]";
	}
	
	public void display()
	{
		add.setHno(12);;
		add.setCity("kolkata");
		add.setColony("nbp");
		System.out.println(eid + ename + add);
		
	}
	

}
