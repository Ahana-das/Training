$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/ahandas/Desktop/Module 4 Sts/RegistrationForm/src/test/resource/Features/registration.feature");
formatter.feature({
  "line": 1,
  "name": "Validating Registration Form",
  "description": "",
  "id": "validating-registration-form",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Verify the title “Welcome to JobsWorld” of the page",
  "description": "",
  "id": "validating-registration-form;verify-the-title-“welcome-to-jobsworld”-of-the-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user is on Registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "verify the title as Welcome to JobsWorld",
  "keyword": "Then "
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_is_on_Registration_page()"
});
formatter.result({
  "duration": 8813261200,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.verify_the_title_as_Welcome_to_JobsWorld()"
});
formatter.result({
  "duration": 3012294100,
  "error_message": "junit.framework.ComparisonFailure: expected:\u003c[Welcome to JobsWorld]\u003e but was:\u003c[]\u003e\r\n\tat junit.framework.Assert.assertEquals(Assert.java:100)\r\n\tat junit.framework.Assert.assertEquals(Assert.java:107)\r\n\tat resgistration.Resgistration_Step_Defination.verify_the_title_as_Welcome_to_JobsWorld(Resgistration_Step_Defination.java:29)\r\n\tat ✽.Then verify the title as Welcome to JobsWorld(C:/Users/ahandas/Desktop/Module 4 Sts/RegistrationForm/src/test/resource/Features/registration.feature:6)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 8,
  "name": "the alert box displays error message  upon clicking on the Submit button without entering any data in the text box",
  "description": "",
  "id": "validating-registration-form;the-alert-box-displays-error-message--upon-clicking-on-the-submit-button-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "user is on Registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "user left the User Id field empty or gave wrong id",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "it will pop-up the alert box displays the error message",
  "keyword": "Then "
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_is_on_Registration_page()"
});
formatter.result({
  "duration": 2921348600,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_left_the_User_Id_field_empty_or_gave_wrong_id()"
});
formatter.result({
  "duration": 3065689800,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 76939700,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.it_will_pop_up_the_alert_box_displays_the_error_message()"
});
formatter.result({
  "duration": 9984605300,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "the alert box displays error message  upon clicking on the Submit button without entering any data in the password text box",
  "description": "",
  "id": "validating-registration-form;the-alert-box-displays-error-message--upon-clicking-on-the-submit-button-without-entering-any-data-in-the-password-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user is on Registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user left the password field empty or gave wrong id",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "it will pop-up the alert box displaying the error message",
  "keyword": "Then "
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_is_on_Registration_page()"
});
formatter.result({
  "duration": 2979845700,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_left_the_password_field_empty_or_gave_wrong_id()"
});
formatter.result({
  "duration": 6123971200,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 71281600,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.it_will_pop_up_the_alert_box_displaying_the_error_message()"
});
formatter.result({
  "duration": 9381696500,
  "status": "passed"
});
formatter.scenario({
  "line": 21,
  "name": "the alert box displays error message  upon clicking on the Submit button without entering any data in the name text box",
  "description": "",
  "id": "validating-registration-form;the-alert-box-displays-error-message--upon-clicking-on-the-submit-button-without-entering-any-data-in-the-name-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 22,
  "name": "user is on Registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "user left the name field empty or gave wrong id",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 25,
  "name": "it will pop-up the alert box will display the error message",
  "keyword": "Then "
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_is_on_Registration_page()"
});
formatter.result({
  "duration": 4439048200,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_left_the_name_field_empty_or_gave_wrong_id()"
});
formatter.result({
  "duration": 9258958800,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 68308400,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.it_will_pop_up_the_alert_box_will_display_the_error_message()"
});
formatter.result({
  "duration": 9248233100,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "the alert box displays error message  upon clicking on the Submit button without entering any data in the address text box",
  "description": "",
  "id": "validating-registration-form;the-alert-box-displays-error-message--upon-clicking-on-the-submit-button-without-entering-any-data-in-the-address-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "user is on Registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "user left the name field empty or gave wrong address",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "it will pop-up the alert box will have to display the error message",
  "keyword": "Then "
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_is_on_Registration_page()"
});
formatter.result({
  "duration": 2587078700,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_left_the_name_field_empty_or_gave_wrong_address()"
});
formatter.result({
  "duration": 12310028900,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 66952200,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.it_will_pop_up_the_alert_box_will_have_to_display_the_error_message()"
});
formatter.result({
  "duration": 9282371600,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "user has not selected any value from country",
  "description": "",
  "id": "validating-registration-form;user-has-not-selected-any-value-from-country",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user is on Registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 36,
  "name": "user has not selected any option from country",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 38,
  "name": "it will pop-up the alert box will be displaying error message",
  "keyword": "Then "
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_is_on_Registration_page()"
});
formatter.result({
  "duration": 2568574800,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_has_not_selected_any_option_from_country()"
});
formatter.result({
  "duration": 15602570700,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 78746300,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.it_will_pop_up_the_alert_box_will_be_displaying_error_message()"
});
formatter.result({
  "duration": 9231064400,
  "status": "passed"
});
formatter.scenario({
  "line": 40,
  "name": "the alert box displays error message  upon clicking on the Submit button without entering any data in the zipcode text box",
  "description": "",
  "id": "validating-registration-form;the-alert-box-displays-error-message--upon-clicking-on-the-submit-button-without-entering-any-data-in-the-zipcode-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 41,
  "name": "user is on Registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 42,
  "name": "user left the name field empty or gave wrong zipcode",
  "keyword": "When "
});
formatter.step({
  "line": 43,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 44,
  "name": "it will pop-up the alert box that shows the error message",
  "keyword": "Then "
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_is_on_Registration_page()"
});
formatter.result({
  "duration": 1491389500,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_left_the_name_field_empty_or_gave_wrong_zipcode()"
});
formatter.result({
  "duration": 18530938400,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 68046400,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.it_will_pop_up_the_alert_box_that_shows_the_error_message()"
});
formatter.result({
  "duration": 9251168400,
  "status": "passed"
});
formatter.scenario({
  "line": 46,
  "name": "the alert box displays error message  upon clicking on the Submit button without entering any data in the email text box",
  "description": "",
  "id": "validating-registration-form;the-alert-box-displays-error-message--upon-clicking-on-the-submit-button-without-entering-any-data-in-the-email-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 47,
  "name": "user is on Registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 48,
  "name": "user left the name field empty or gave wrong email",
  "keyword": "When "
});
formatter.step({
  "line": 49,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 50,
  "name": "it will pop-up the alert box that will show the error message",
  "keyword": "Then "
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_is_on_Registration_page()"
});
formatter.result({
  "duration": 2452065900,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_left_the_name_field_empty_or_gave_wrong_email()"
});
formatter.result({
  "duration": 21530336600,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 63034900,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.it_will_pop_up_the_alert_box_that_will_show_the_error_message()"
});
formatter.result({
  "duration": 9398100900,
  "status": "passed"
});
formatter.scenario({
  "line": 52,
  "name": "the alert box displays error message  upon clicking on the Submit button without selecting any gender",
  "description": "",
  "id": "validating-registration-form;the-alert-box-displays-error-message--upon-clicking-on-the-submit-button-without-selecting-any-gender",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 53,
  "name": "user is on Registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 54,
  "name": "user left the gender radio buttons empty",
  "keyword": "When "
});
formatter.step({
  "line": 55,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 56,
  "name": "it will pop-up the alert box and will show the error message",
  "keyword": "Then "
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_is_on_Registration_page()"
});
formatter.result({
  "duration": 1761160600,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_left_the_gender_radio_buttons_empty()"
});
formatter.result({
  "duration": 24620711100,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 63791300,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.it_will_pop_up_the_alert_box_and_will_show_the_error_message()"
});
formatter.result({
  "duration": 9270200900,
  "status": "passed"
});
formatter.scenario({
  "line": 58,
  "name": "after filling up all details, we have to click on submit button",
  "description": "",
  "id": "validating-registration-form;after-filling-up-all-details,-we-have-to-click-on-submit-button",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 59,
  "name": "user is on Registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 60,
  "name": "user gives all correct entries",
  "keyword": "When "
});
formatter.step({
  "line": 61,
  "name": "click on Submit button",
  "keyword": "Then "
});
formatter.step({
  "line": 62,
  "name": "it will pop-up the alert box and will show that it is registered",
  "keyword": "Then "
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_is_on_Registration_page()"
});
formatter.result({
  "duration": 1778104300,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.user_gives_all_correct_entries()"
});
formatter.result({
  "duration": 30900772900,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.click_on_Submit_button()"
});
formatter.result({
  "duration": 66305700,
  "status": "passed"
});
formatter.match({
  "location": "Resgistration_Step_Defination.it_will_pop_up_the_alert_box_and_will_show_that_it_is_registered()"
});
formatter.result({
  "duration": 9154321600,
  "status": "passed"
});
});