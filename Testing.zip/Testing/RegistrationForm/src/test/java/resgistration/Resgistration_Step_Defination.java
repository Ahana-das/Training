package resgistration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import factory.RegistrationFactory;
import junit.framework.Assert;


public class Resgistration_Step_Defination {
	public WebDriver driver;
	public RegistrationFactory factory;
	
	@Given("^user is on Registration page$")
	public void user_is_on_Registration_page()  {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ahandas\\Desktop\\ChromeDriverNew\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("C:\\Users\\ahandas\\Desktop\\WebPages Set A\\RegistrationForm.html");
	    factory=new RegistrationFactory(driver);
	}

	@Then("^verify the title as Welcome to JobsWorld$")
	public void verify_the_title_as_Welcome_to_JobsWorld() throws InterruptedException  {
		Thread.sleep(3000);
		String title = driver.getTitle();
		Assert.assertEquals("Welcome to JobsWorld", title);
		if(title.equals("Welcome to JobsWorld")) {
			System.out.println("Title Matched");
		}
		else {
			System.out.println("Title DidNot Match");
		}
	    
	}
	@When("^user left the User Id field empty or gave wrong id$")
	public void user_left_the_User_Id_field_empty_or_gave_wrong_id() throws InterruptedException  {
		Thread.sleep(3000);
		factory.setUserId("");
	}

	@Then("^click on Confirm Booking button$")
	public void click_on_Confirm_Booking_button()  {
	    factory.setSubmitButton();
	}

	@Then("^it will pop-up the alert box displays the error message$")
	public void it_will_pop_up_the_alert_box_displays_the_error_message() throws InterruptedException  {
		Thread.sleep(3000);
		String expectedMessage="User Id should not be empty / length be between 5 to 12";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}
	
	@When("^user left the password field empty or gave wrong id$")
	public void user_left_the_password_field_empty_or_gave_wrong_id() throws InterruptedException  {
		Thread.sleep(3000);
		factory.setUserId("ahanadas");
		Thread.sleep(3000);
		factory.setPassword("");
	    
	}

	@Then("^it will pop-up the alert box displaying the error message$")
	public void it_will_pop_up_the_alert_box_displaying_the_error_message() throws InterruptedException  {
		
		Thread.sleep(3000);
		String expectedMessage="Password should not be empty / length be between 7 to 12";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	   
	}
	
	@When("^user left the name field empty or gave wrong id$")
	public void user_left_the_name_field_empty_or_gave_wrong_id() throws InterruptedException  {
		Thread.sleep(3000);
		factory.setUserId("ahanadas");
		Thread.sleep(3000);
		factory.setPassword("2589631475");
		Thread.sleep(3000);
		factory.setName("");
	    
	}

	@Then("^it will pop-up the alert box will display the error message$")
	public void it_will_pop_up_the_alert_box_will_display_the_error_message() throws Throwable {
		Thread.sleep(3000);
		String expectedMessage="Name should not be empty and must have alphabet characters only";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}
	
	@When("^user left the name field empty or gave wrong address$")
	public void user_left_the_name_field_empty_or_gave_wrong_address() throws InterruptedException  {
		Thread.sleep(3000);
		factory.setUserId("ahanadas");
		Thread.sleep(3000);
		factory.setPassword("2589631475");
		Thread.sleep(3000);
		factory.setName("Ahana");
		Thread.sleep(3000);
		factory.setAddress(""); 
	}

	@Then("^it will pop-up the alert box will have to display the error message$")
	public void it_will_pop_up_the_alert_box_will_have_to_display_the_error_message() throws InterruptedException  {
		Thread.sleep(3000);
		String expectedMessage="User address must have alphanumeric characters only";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}
	
	@When("^user has not selected any option from country$")
	public void user_has_not_selected_any_option_from_country() throws InterruptedException  {
		Thread.sleep(3000);
		factory.setUserId("ahanadas");
		Thread.sleep(3000);
		factory.setPassword("2589631475");
		Thread.sleep(3000);
		factory.setName("Ahana");
		Thread.sleep(3000);
		factory.setAddress("kolkata"); 
		Thread.sleep(3000);
		factory.setCountry("(Please select a country)");
	}

	@Then("^it will pop-up the alert box will be displaying error message$")
	public void it_will_pop_up_the_alert_box_will_be_displaying_error_message() throws InterruptedException  {
		Thread.sleep(3000);
		String expectedMessage="Select your country from the list";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}
	
	@When("^user left the name field empty or gave wrong zipcode$")
	public void user_left_the_name_field_empty_or_gave_wrong_zipcode() throws InterruptedException  {
		Thread.sleep(3000);
		factory.setUserId("ahanadas");
		Thread.sleep(3000);
		factory.setPassword("2589631475");
		Thread.sleep(3000);
		factory.setName("Ahana");
		Thread.sleep(3000);
		factory.setAddress("kolkata"); 
		Thread.sleep(3000);
		factory.setCountry("India");
		Thread.sleep(3000);
		factory.setZipCode("");
	}

	@Then("^it will pop-up the alert box that shows the error message$")
	public void it_will_pop_up_the_alert_box_that_shows_the_error_message() throws InterruptedException  {
		Thread.sleep(3000);
		String expectedMessage="ZIP code must have numeric characters only";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	   
	}
	
	@When("^user left the name field empty or gave wrong email$")
	public void user_left_the_name_field_empty_or_gave_wrong_email() throws InterruptedException  {
		Thread.sleep(3000);
		factory.setUserId("ahanadas");
		Thread.sleep(3000);
		factory.setPassword("2589631475");
		Thread.sleep(3000);
		factory.setName("Ahana");
		Thread.sleep(3000);
		factory.setAddress("kolkata"); 
		Thread.sleep(3000);
		factory.setCountry("India");
		Thread.sleep(3000);
		factory.setZipCode("214");
		Thread.sleep(3000);
		factory.setEmail("");
	}

	@Then("^it will pop-up the alert box that will show the error message$")
	public void it_will_pop_up_the_alert_box_that_will_show_the_error_message() throws InterruptedException  {
		Thread.sleep(3000);
		String expectedMessage="You have entered an invalid email address!";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	  
	}
	
	@When("^user left the gender radio buttons empty$")
	public void user_left_the_gender_radio_buttons_empty() throws InterruptedException  {
		Thread.sleep(3000);
		factory.setUserId("ahanadas");
		Thread.sleep(3000);
		factory.setPassword("2589631475");
		Thread.sleep(3000);
		factory.setName("Ahana");
		Thread.sleep(3000);
		factory.setAddress("kolkata"); 
		Thread.sleep(3000);
		factory.setCountry("India");
		Thread.sleep(3000);
		factory.setZipCode("214");
		Thread.sleep(3000);
		factory.setEmail("ahana@gmail.com");
		Thread.sleep(3000);
	}

	@Then("^it will pop-up the alert box and will show the error message$")
	public void it_will_pop_up_the_alert_box_and_will_show_the_error_message() throws InterruptedException  {
		Thread.sleep(3000);
		String expectedMessage="Please Select gender";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}
	
	@When("^user gives all correct entries$")
	public void user_gives_all_correct_entries() throws InterruptedException  {
		Thread.sleep(3000);
		factory.setUserId("ahanadas");
		Thread.sleep(3000);
		factory.setPassword("2589631475");
		Thread.sleep(3000);
		factory.setName("Ahana");
		Thread.sleep(3000);
		factory.setAddress("kolkata"); 
		Thread.sleep(3000);
		factory.setCountry("India");
		Thread.sleep(3000);
		factory.setZipCode("214");
		Thread.sleep(3000);
		factory.setEmail("ahana@gmail.com");
		Thread.sleep(3000);
		factory.setSex();
		Thread.sleep(3000);
		factory.setAbout("Hey I am Ahana");
		Thread.sleep(3000);
	}

	@Then("^click on Submit button$")
	public void click_on_Submit_button() throws Throwable {
		factory.setSubmitButton();
		
	}
	
	@Then("^it will pop-up the alert box and will show that it is registered$")
	public void it_will_pop_up_the_alert_box_and_will_show_that_it_is_registered() throws InterruptedException  {
		Thread.sleep(3000);
		String expectedMessage="Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}


	





}
