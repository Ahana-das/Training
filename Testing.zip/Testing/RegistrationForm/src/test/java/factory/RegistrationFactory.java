package factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistrationFactory {

	WebDriver driver;
	
	//step 1 : identify elements
		@FindBy(id="usrID")
		@CacheLookup
		WebElement userId;
		
		@FindBy(id="pwd")
		@CacheLookup
		WebElement password;
		
		@FindBy(id="usrname")
		@CacheLookup
		WebElement name;
		
		@FindBy(id="addr")
		@CacheLookup
		WebElement address;
		
		@FindBy(name="country")
		@CacheLookup
		WebElement country;
		
		@FindBy(name="zip")
		@CacheLookup
		WebElement zipCode;
		
		@FindBy(name="email")
		@CacheLookup
		WebElement email;
		
		@FindBy(name="sex")
		@CacheLookup
		WebElement sex;
		
		@FindBy(name="en")
		@CacheLookup
		WebElement language;
		
		
		@FindBy(name="submit")
		@CacheLookup
		WebElement submitButton;



		@FindBy(id="desc")
		@CacheLookup
		WebElement about;

		


		public WebElement getAbout() {
			return about;
		}


		public void setAbout(String about) {
			this.about.sendKeys(about);;
		}


		public WebElement getUserId() {
			return userId;
		}


		public void setUserId(String userId) {
			this.userId.sendKeys(userId);
		}
		
		
		public WebElement getPassword() {
			return password;
		}


		public void setPassword(String password) {
			this.password.sendKeys(password);
		}


		public WebElement getName() {
			return name;
		}


		public void setName(String name) {
			this.name.sendKeys(name);;
		}


		public WebElement getAddress() {
			return address;
		}


		public void setAddress(String address) {
			this.address.sendKeys(address);;
		}


		public WebElement getCountry() {
			return country;
		}


		public void setCountry(String inputcountry) {
			Select Country_Select = new Select(country);
		Country_Select.selectByVisibleText(inputcountry);
		}


		public WebElement getZipCode() {
			return zipCode;
		}


		public void setZipCode(String zipCode) {
			this.zipCode.sendKeys(zipCode);;
		}


		public WebElement getEmail() {
			return email;
		}


		public void setEmail(String email) {
			this.email.sendKeys(email);;
		}


		public WebElement getSex() {
			return sex;
		}


		public void setSex() {
			this.sex.click();
		}


		public WebElement getLanguage() {
			return language;
		}


		public void setLanguage(WebElement language) {
			this.language = language;
		}


		public WebElement getSubmitButton() {
			return submitButton;
		}


		public void setSubmitButton() {
			this.submitButton.click();
		}


		public RegistrationFactory(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
		
		
		
		
		

}
