package com.cap.Tool;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\ahandas\\Desktop\\Module 4 Sts\\NewTool\\src\\test\\resource\\Features\\newtool.feature"},
		glue= {"com.cap.Tool"},
		dryRun = true,
		strict = true,
		monochrome= true,
		format = {"pretty" , "html:test-output"}
		
		)
public class New_Tool_Test_Runner {

}
