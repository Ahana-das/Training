package com.cap.Tool;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class New_Tool_Step_defination {
	
	public WebDriver driver;
	
	@Before
    public void StartUp()
    {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\aggeorge\\Desktop\\ChromeDriver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage().deleteAllCookies();
        //page obj eludhanum idhula.
        driver.get("http://newtours.demoaut.com/");
    }
    @After
    public void TearDown()
    {
        driver.quit();
    }
	
	@Given("^the user is on login page$")
	public void the_user_is_on_login_page() {
	}

	@Then("^the user enter to \"([^\"]*)\" and \"([^\"]*)\"$")
	public void the_user_enter_to_and(String arg1, String arg2) {
	}

	@Then("^the user should click in the signin button$")
	public void the_user_should_click_in_the_signin_button() {
	}

	@Given("^the user is on Flight reservation page$")
	public void the_user_is_on_Flight_reservation_page() {
	   
	}

	@Then("^select the passenger count$")
	public void select_the_passenger_count(DataTable arg1)  {
	
	}

	@Then("^user to enter \"([^\"]*)\" and \"([^\"]*)\" location$")
	public void user_to_enter_and_location(String arg1, String arg2)  {
	   
	}

	@Then("^click on continue booking$")
	public void click_on_continue_booking()  {
	    
	}



}
