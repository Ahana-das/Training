package com.cap.Login;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\ahandas\\Desktop\\Module 4 Sts\\LoginEx\\src\\test\\resource\\Features\\login.feature"},
		glue= {"com.cap.Login"},
		dryRun = false,
		strict = true,
		monochrome= true,
		format = {"pretty" , "html:test-output"}
		
		)

public class Login_Test_Runner {

}
