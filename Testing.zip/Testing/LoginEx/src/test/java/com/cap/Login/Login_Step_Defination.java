package com.cap.Login;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Login_Step_Defination {
	WebDriver Driver;
	@Given("^user is present in the login page$")
	public void user_is_present_in_the_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ahandas\\Desktop\\ChromeDriver\\chromedriver.exe");
		Driver = new ChromeDriver();
		Driver.get("C:\\Users\\ahandas\\Desktop\\BDDCaseStudyFinal\\login.html");
	  
	}

	@Then("^verify login page heading as \"([^\"]*)\" using xpath$")
	public void verify_login_page_heading_as_using_xpath(String arg1) throws Throwable {
		 String abc=Driver.findElement(By.tagName("h1")).getText();
	        System.out.println(abc);
	        Assert.assertEquals("Hotel Booking Application", abc);
	}



}
