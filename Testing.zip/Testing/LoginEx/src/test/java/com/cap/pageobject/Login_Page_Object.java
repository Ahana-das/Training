package com.cap.pageobject;

public class Login_Page_Object {

}
