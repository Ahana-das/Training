$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/ahandas/Desktop/Module 4 Sts/LoginEx/src/test/resource/Features/login.feature");
formatter.feature({
  "line": 1,
  "name": "To validate the login form",
  "description": "",
  "id": "to-validate-the-login-form",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "To check whether the user is present in hotel login form or not",
  "description": "",
  "id": "to-validate-the-login-form;to-check-whether-the-user-is-present-in-hotel-login-form-or-not",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user is present in the login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "verify login page heading as \"Hotel Booking Application\" using xpath",
  "keyword": "Then "
});
formatter.match({
  "location": "Login_Step_Defination.user_is_present_in_the_login_page()"
});
formatter.result({
  "duration": 3364459001,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Hotel Booking Application",
      "offset": 30
    }
  ],
  "location": "Login_Step_Defination.verify_login_page_heading_as_using_xpath(String)"
});
formatter.result({
  "duration": 40434301,
  "status": "passed"
});
});