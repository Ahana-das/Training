package amazon_Test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(

	features= {"C:\\Users\\ahandas\\Desktop\\Module 4 Sts\\FirstExampleUsingSelenium\\src\\test\\resource\\Features\\amazon.feature"},
	glue= {"amazon_Test"},
	dryRun = false,
	strict = true,
	monochrome= true,
	format = {"pretty" , "html:test-output"}

)

public class Amazon_Test_Runner {
	
	
}
