$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/ahandas/Desktop/Module 4 Sts/FirstExampleUsingSelenium/src/test/resource/Features/amazon.feature");
formatter.feature({
  "line": 1,
  "name": "validating the Amazon site",
  "description": "",
  "id": "validating-the-amazon-site",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Search an item and get the title",
  "description": "",
  "id": "validating-the-amazon-site;search-an-item-and-get-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "the user is on the amazon home page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "select the category as Books",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "enter Da Vinci code in the search text",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "click on magnifier button",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "get the title of the books and print",
  "keyword": "Then "
});
formatter.match({
  "location": "Search_item_Step_Defination.the_user_is_on_the_amazon_home_page()"
});
formatter.result({
  "duration": 17993430501,
  "status": "passed"
});
formatter.match({
  "location": "Search_item_Step_Defination.select_the_category_as_Books()"
});
formatter.result({
  "duration": 318424500,
  "error_message": "org.openqa.selenium.NoSuchWindowException: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome\u003d78.0.3904.70)\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DIN77003668\u0027, ip: \u002710.219.35.60\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_181\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 78.0.3904.70, chrome: {chromedriverVersion: 77.0.3865.40 (f484704e052e0..., userDataDir: C:\\Users\\ahandas\\AppData\\Lo...}, goog:chromeOptions: {debuggerAddress: localhost:59899}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify}\nSession ID: 242c84da588a4cf5db5d7730913a6989\n*** Element info: {Using\u003dxpath, value\u003d//select[@id\u003d\u0027searchDropdownBox\u0027]}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:322)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:424)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:353)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:314)\r\n\tat amazon_Test.Search_item_Step_Defination.select_the_category_as_Books(Search_item_Step_Defination.java:30)\r\n\tat ✽.Then select the category as Books(C:/Users/ahandas/Desktop/Module 4 Sts/FirstExampleUsingSelenium/src/test/resource/Features/amazon.feature:6)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "Search_item_Step_Defination.enter_Da_Vinci_code_in_the_search_text()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "Search_item_Step_Defination.click_on_magnifier_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "Search_item_Step_Defination.get_the_title_of_the_books_and_print()"
});
formatter.result({
  "status": "skipped"
});
});