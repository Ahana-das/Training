package com.capgemini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceCalculator46005714Application {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceCalculator46005714Application.class, args);
	}

}
